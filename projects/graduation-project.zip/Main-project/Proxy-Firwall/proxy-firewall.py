import socket
import threading
from urllib.parse import urlparse
import re
import gzip
import io
import os
import logging
from waitress import serve
from flask import Flask, render_template_string, request, redirect, url_for,session,flash
import bcrypt
import json
import secrets
import requests
import time

file_lock = threading.Lock()

alert_cooldowns = {}  # host -> last_alert_time
ALERT_COOLDOWN_SECONDS = 180

def ensure_data_files():
    os.makedirs("data", exist_ok=True)

    defaults = {
        "blocked_sites.txt": "",
        "filtered_words.txt": "",
        "word_replacements.txt": "",
	    "blocked_extensions.txt": ""
    }

    for filename, default_content in defaults.items():
        path = os.path.join("data", filename)
        if not os.path.exists(path) or os.path.getsize(path) == 0:
            with open(path, 'w') as f:
                f.write(default_content)
            logging.warning(f"{filename} was missing or empty. Created with default content.")


def send_telegram_alert(message):
    config_file = "data/user_config.json"
    if not os.path.exists(config_file):
        logging.warning("Telegram config not found.")
        return

    with open(config_file, "r") as f:
        config = json.load(f)

    bot_token = config.get("bot_token")
    chat_id = config.get("chat_id")

    if not bot_token or not chat_id:
        logging.warning("Telegram config missing token or chat_id.")
        return

    url = f"https://api.telegram.org/bot{bot_token}/sendMessage"
    payload = {"chat_id": chat_id, "text": message}

    try:
        r = requests.post(url, data=payload)
        if r.status_code != 200:
            logging.warning(f"Telegram alert failed: {r.text}")
        else:
            logging.info("Telegram alert sent.")
    except Exception as e:
        logging.error(f"Error sending Telegram alert: {e}")


def trigger_alert_once(event_key, message):
    current_time = time.time()
    last_alert_time = alert_cooldowns.get(event_key, 0)
    if current_time - last_alert_time > ALERT_COOLDOWN_SECONDS:
        send_telegram_alert(message)
        alert_cooldowns[event_key] = current_time
    else:
        logging.info(f"Skipped alert for {event_key} (within cooldown)")



os.makedirs("user", exist_ok=True)
os.makedirs("logs", exist_ok=True)

os.makedirs("static", exist_ok=True)
if not os.path.exists("static/blocked.html"):
    with open("static/blocked.html", "w") as f:
        f.write("<h1>This site is blocked.</h1>")

# ===== Logging Setup =====
LOG_FILE = "logs/proxy.log"
HTTPS_LOG_FILE = "logs/https_connect.log"

https_logger = logging.getLogger("https_connect")
https_logger.setLevel(logging.INFO)

# File handler for HTTPS CONNECT logs
https_handler = logging.FileHandler(HTTPS_LOG_FILE)
https_handler.setLevel(logging.INFO)
https_formatter = logging.Formatter('%(asctime)s [%(levelname)s] %(message)s', '%Y-%m-%d %H:%M:%S')
https_handler.setFormatter(https_formatter)
https_logger.addHandler(https_handler)

logging.basicConfig(
    filename=LOG_FILE,
    level=logging.DEBUG,
    format='%(asctime)s [%(levelname)s] %(message)s',
    datefmt='%Y-%m-%d %H:%M:%S'
)
# Also print to console
console = logging.StreamHandler()
console.setLevel(logging.DEBUG)
formatter = logging.Formatter('%(asctime)s [%(levelname)s] %(message)s', '%Y-%m-%d %H:%M:%S')
console.setFormatter(formatter)
logging.getLogger('').addHandler(console)

# ==========================

PROXY_HOST = '0.0.0.0'
PROXY_PORT = 8080
BUFFER_SIZE = 8192
TIMEOUT = 5

def load_filters():
    block_patterns = []
    word_filters = set()
    word_replacements = {}
    whitelist_patterns = []
    whitelist_enabled = False  # Default: whitelist is disabled

    with file_lock:
        # ===== Load blocked sites =====
        try:
            with open("data/blocked_sites.txt", "r") as f:
                for line in f:
                    line = line.strip()
                    if not line or line.startswith("#"):
                        continue

                    if "->" in line:
                        pattern, page = map(str.strip, line.split("->", 1))
                    else:
                        pattern = line
                        page = "static/blocked.html"

                    # Auto-convert plain domains to regex
                    if not pattern.startswith("^"):
                       domain = re.escape(pattern)
                       pattern = r"^([a-z0-9-]+\.)*" + domain + r"(/.*)?$"


                    try:
                        block_patterns.append((re.compile(pattern, re.IGNORECASE), page))
                    except re.error as e:
                        logging.warning(f"Invalid regex in blocked_sites.txt: {pattern} -> {e}")
        except FileNotFoundError:
            logging.warning("blocked_sites.txt not found.")

        # ===== Load filtered words =====
        try:
            with open("data/filtered_words.txt", "r") as f:
                word_filters.update(word.strip() for word in f if word.strip())
        except FileNotFoundError:
            logging.warning("filtered_words.txt not found.")

        # ===== Load word replacements =====
        try:
            with open("data/word_replacements.txt", "r") as f:
                for line in f:
                    if '->' in line:
                        original, replacement = line.strip().split('->', 1)
                        word_replacements[original.strip()] = replacement.strip()
        except FileNotFoundError:
            logging.warning("word_replacements.txt not found.")

        # ===== Load whitelist entries =====
        try:
            with open("data/whitelist.txt", "r") as f:
                for line in f:
                    line = line.strip()
                    if not line or line.startswith("#"):
                        continue

                    # Auto-convert plain domains to regex
                    if not line.startswith("^"):
                       domain = re.escape(line)
                       line = r"^([a-z0-9-]+\.)*" + domain + r"(/.*)?$"


                    try:
                        whitelist_patterns.append(re.compile(line, re.IGNORECASE))
                    except re.error as e:
                        logging.warning(f"Invalid regex in whitelist.txt: {line} -> {e}")
        except FileNotFoundError:
            logging.warning("whitelist.txt not found.")

        # ===== Load whitelist toggle =====
        try:
            with open("data/user_config.json", "r") as f:
                config = json.load(f)
                whitelist_enabled = config.get("whitelist_enabled", False)
        except Exception:
            logging.warning("Could not load whitelist_enabled flag.")

    return block_patterns, word_filters, word_replacements, whitelist_patterns, whitelist_enabled

def load_blocked_extensions():
    blocked_exts = set()
    ext_file = os.path.join("data", "blocked_extensions.txt")  
    if os.path.exists(ext_file):
        with open(ext_file, "r") as f:
            for line in f:
                ext = line.strip().lower()
                if ext:
                    blocked_exts.add(ext)
    return blocked_exts

def auto_block_site(host):
    line = f"{host} -> static/blocked.html\n"
    with file_lock:
        if os.path.exists("data/blocked_sites.txt"):
            with open("data/blocked_sites.txt", "r") as f:
                if host in f.read():
                    return
        with open("data/blocked_sites.txt", "a") as f:
            f.write(line)
            logging.info(f"Auto-blocked site: {host}")

def handle_client(client_socket):
    try:
        request = client_socket.recv(BUFFER_SIZE)
        request_str = request.decode('utf-8', errors='ignore')
        logging.debug(f"Received request:\n{request_str}")

        lines = request_str.split('\r\n')
        if len(lines) < 1:
            client_socket.close()
            return

        request_line = lines[0]
        parts = request_line.split()
        if len(parts) != 3:
            client_socket.close()
            return

        method, full_url, protocol = parts
        parsed = urlparse(full_url)
        host = parsed.hostname
        path = parsed.path or "/"
        query = f"?{parsed.query}" if parsed.query else ""
        full_path = path + query

        block_sites, word_filters, word_replacements, whitelist_patterns, whitelist_enabled = load_filters()

        file_extension = None
        if '.' in path:  
            file_extension = path.split('.')[-1].lower().split('?')[0].split('#')[0]


        if file_extension and file_extension in load_blocked_extensions():
            trigger_alert_once(f"ext_block:{file_extension}",
                            f"🚫 A file with the .{file_extension} extension was blocked from {host}")
            client_socket.sendall(b"HTTP/1.1 403 Forbidden\r\n\r\n" + "This file type is blocked".encode('utf-8'))
            logging.info(f"[EXTENSION BLOCKED] Blocked .{file_extension} from {host}")
            return

        # ===== Handle HTTPS CONNECT requests =====
        ALLOWED_PORTS = {443, 8443}

        if method.upper() == 'CONNECT':
            try:
                host, port = full_url.split(':')
                port = int(port)

                https_logger.info(f"[CONNECT] Requested HTTPS tunnel to {host}:{port} from IP {client_socket.getpeername()[0]}")


                # Enforce whitelist for HTTPS
                if whitelist_enabled:
                    if not any(pattern.match(host) for pattern in whitelist_patterns):
                        trigger_alert_once(
                            f"https_whitelist_block:{host}",
                            f"❌ Blocked non-whitelisted HTTPS domain: {host}"
                        )
                        client_socket.sendall(b"HTTP/1.1 403 Forbidden\r\n\r\nDomain not allowed.")
                        logging.warning(f"[WHITELIST BLOCK - HTTPS] {host} is not in whitelist")
                        return

                if port not in ALLOWED_PORTS:
                    trigger_alert_once(f"https_port_block:{host}:{port}",
                        f"🚫 Blocked CONNECT: {host}:{port} from IP {client_socket.getpeername()[0]}")
                    logging.warning(f"[BLOCKED PORT] CONNECT to disallowed port {port} on {host}")
                    if port not in ALLOWED_PORTS:
                        https_logger.warning(f"[BLOCKED PORT] HTTPS to {host}:{port} blocked")
                        https_logger.info(f"[ALLOWED] HTTPS tunnel established for {host}:{port}")
                        client_socket.sendall(b"HTTP/1.1 403 Forbidden\r\n\r\n")
                        return

                # Check against blocked sites
                for pattern, _ in block_sites:
                    if pattern.match(host):
                        trigger_alert_once(
                            f"https_block:{host}",
                            f"🚫 Blocked HTTPS: {host} from IP {client_socket.getpeername()[0]}"
                        )
                        client_socket.sendall(b"HTTP/1.1 403 Forbidden\r\n\r\n")
                        logging.info(f"[HTTPS BLOCKED] {host} matched pattern {pattern.pattern}")
                        return

                # Establish tunnel
                with socket.create_connection((host, port), timeout=TIMEOUT) as remote_socket:
                    client_socket.sendall(b"HTTP/1.1 200 Connection Established\r\n\r\n")

                    client_socket.setblocking(False)
                    remote_socket.setblocking(False)

                    while True:
                        try:
                            data_from_client = client_socket.recv(BUFFER_SIZE)
                            if data_from_client:
                                remote_socket.sendall(data_from_client)
                        except BlockingIOError:
                            pass

                        try:
                            data_from_server = remote_socket.recv(BUFFER_SIZE)
                            if data_from_server:
                                client_socket.sendall(data_from_server)
                        except BlockingIOError:
                            pass

            except Exception as e:
                logging.error(f"[HTTPS TUNNEL ERROR] {host}:{port} -> {e}")
            finally:
                logging.info(f"[TUNNEL CLOSED] HTTPS tunnel closed for {host}")
            return

        # ===== HTTP REQUEST HANDLING =====

        # Enforce whitelist for HTTP
        if whitelist_enabled:
            if not any(pattern.match(host) for pattern in whitelist_patterns):
                trigger_alert_once(
                    f"whitelist_block:{host}",
                    f"❌ Blocked non-whitelisted domain: {host}"
                )
                client_socket.sendall(b"HTTP/1.1 403 Forbidden\r\n\r\nDomain not allowed.")
                logging.warning(f"[WHITELIST BLOCK - HTTP] {host} is not in whitelist")
                return

        # Check if host is blocked
        for pattern, filename in block_sites:
            if pattern.match(host):
                trigger_alert_once(f"http_block:{host}",
                    f"🚫 Blocked HTTP: {host} from IP {client_socket.getpeername()[0]}")
                try:
                    with file_lock:
                        with open(filename, 'rb') as f:
                            html = f.read()
                    response = b"HTTP/1.1 200 OK\r\nContent-Type: text/html\r\n\r\n" + html
                    client_socket.sendall(response)
                    logging.info(f"Blocked {host} using pattern {pattern.pattern}, served {filename}")
                except FileNotFoundError:
                    client_socket.sendall(b"HTTP/1.1 404 Not Found\r\n\r\nBlocked page not found.")
                    logging.error(f"Blocked file {filename} not found for pattern {pattern.pattern}")
                return

        # Clean headers and reconstruct request
        lines = [line for line in lines if not line.lower().startswith("accept-encoding:")]
        lines[0] = f"{method} {full_path} {protocol}"
        updated_request = "\r\n".join(lines) + "\r\n\r\n"

        port = 80
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as server_socket:
            server_socket.settimeout(TIMEOUT)
            server_socket.connect((host, port))
            server_socket.sendall(updated_request.encode('utf-8'))

            response = b''
            while True:
                chunk = server_socket.recv(BUFFER_SIZE)
                if not chunk:
                    break
                response += chunk

        if b"Content-Type: text/html" in response:
            headers, body = response.split(b"\r\n\r\n", 1)
            is_gzipped = b"Content-Encoding: gzip" in headers
            try:
                if is_gzipped:
                    buf = io.BytesIO(body)
                    f = gzip.GzipFile(fileobj=buf)
                    body_str = f.read().decode('utf-8', errors='ignore')
                else:
                    body_str = body.decode('utf-8', errors='ignore')
            except Exception as e:
                logging.error(f"Decompression failed: {e}")
                body_str = ''

            # Word filtering auto-block
            if any(re.search(rf'\b{re.escape(word)}\b', body_str, flags=re.IGNORECASE) for word in word_filters):
                auto_block_site(host)
                trigger_alert_once(f"word_block:{host}",
                    f"🛑 Filtered word found on {host}, site auto-blocked. IP: {client_socket.getpeername()[0]}")
                try:
                    with file_lock:
                        with open("static/blocked.html", 'rb') as f:
                            blocked_content = f.read()
                    response = b"HTTP/1.1 200 OK\r\nContent-Type: text/html\r\n\r\n" + blocked_content
                    client_socket.sendall(response)
                    logging.info(f"Site contained filtered word. Blocked: {host}")
                    return
                except FileNotFoundError:
                    client_socket.sendall(b"HTTP/1.1 403 Forbidden\r\n\r\nBlocked content.")
                    logging.error("blocked.html not found while trying to serve blocked page.")
                    return

            # Word replacement
            replacements_made = False
            for word, replacement in word_replacements.items():
                new_body_str = re.sub(rf'\b{re.escape(word)}\b', replacement, body_str, flags=re.IGNORECASE)
                if new_body_str != body_str:
                    replacements_made = True
                    body_str = new_body_str

            if replacements_made:
                trigger_alert_once(f"replacement:{host}",
                    f"✏️ Content filtered on {host}, word replacements applied. IP: {client_socket.getpeername()[0]}")

            try:
                if is_gzipped:
                    out_buf = io.BytesIO()
                    with gzip.GzipFile(fileobj=out_buf, mode='wb') as gzfile:
                        gzfile.write(body_str.encode('utf-8'))
                    new_body = out_buf.getvalue()
                else:
                    new_body = body_str.encode('utf-8')

                response = headers + b"\r\n\r\n" + new_body
                logging.debug("Word filtering and replacement applied.")
            except Exception as e:
                logging.error(f"Error during re-encoding: {e}")

        client_socket.sendall(response)

    except Exception as e:
        logging.exception(f"Error handling client: {e}")
    finally:
        client_socket.close()
        logging.info("Client connection closed.")




def start_proxy():
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as server:
        server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        try:
            server.bind((PROXY_HOST, PROXY_PORT))
            server.listen(5)
            logging.info(f"Proxy server listening on {PROXY_HOST}:{PROXY_PORT}")
        except OSError as e:
            logging.error(f"Could not bind proxy on {PROXY_HOST}:{PROXY_PORT}: {e}")
            return  # Exit cleanly if port is already in use
        while True:
            client_socket, addr = server.accept()
            logging.info(f"Accepted connection from {addr[0]}:{addr[1]}")
            threading.Thread(target=handle_client, args=(client_socket,)).start()

# ==========================
# Flask Web App
# ==========================

app = Flask(__name__)


app.secret_key = secrets.token_hex(16)

CREDENTIALS_FILE = "user/credentials.json"


def credentials_exist():
    return os.path.exists(CREDENTIALS_FILE)


def save_credentials(username, password):
    hashed = bcrypt.hashpw(password.encode(), bcrypt.gensalt())
    data = {"username": username, "password": hashed.decode()}
    with open(CREDENTIALS_FILE, "w") as f:
        json.dump(data, f)

def load_credentials():
    with open(CREDENTIALS_FILE, "r") as f:
        return json.load(f)

def verify_credentials(input_user, input_pass):
    try:
        creds = load_credentials()
        return input_user == creds["username"] and bcrypt.checkpw(input_pass.encode(), creds["password"].encode())
    except Exception as e:
        logging.warning("Credential verification failed:", e)
        return False

@app.route("/login", methods=["GET", "POST"])
def login():
    if not credentials_exist():
        return redirect(url_for("register"))

    if request.method == "POST":
        username = request.form["username"]
        password = request.form["password"]
        user_ip = request.remote_addr

        if verify_credentials(username, password):
            session["user"] = username
            logging.info(f"[AUTH] Successful login for user '{username}' from IP {user_ip}")
            trigger_alert_once(f"login_success:{user_ip}",f"✅ Successful login by '{username}' from IP: {user_ip}")
            return redirect(url_for("index"))

        logging.warning(f"[AUTH] Failed login attempt for username '{username}' from IP {user_ip}")
        trigger_alert_once(f"login_fail:{user_ip}",f"❌ Failed login attempt with username '{username}' from IP: {user_ip}")
        flash("Invalid credentials, try again.", "error")

    return render_template_string(LOGIN_TEMPLATE)

@app.route("/logs/auth")
def view_auth_logs():
    if os.path.exists(LOG_FILE):
        with open(LOG_FILE, "r") as f:
            auth_lines = [line for line in f if "[AUTH]" in line]
            return "<pre>" + "".join(auth_lines[-100:]) + "</pre>"  # Last 100 auth lines
    return "No logs found."

@app.route("/register", methods=["GET", "POST"])
def register():
    if credentials_exist():
        return redirect(url_for("login"))

    if request.method == "POST":
        username = request.form["username"]
        password = request.form["password"]
        user_ip = request.remote_addr

        if username and password:
            save_credentials(username, password)
            session["user"] = username
            logging.info(f"[AUTH] New user '{username}' registered from IP {user_ip}")
            trigger_alert_once(f"register:{user_ip}",f"🆕 New registration: '{username}' from IP: {user_ip}")
            return redirect(url_for("index"))
        flash("Username and password required", "error")
    return render_template_string(REGISTER_TEMPLATE)

@app.route("/logout")
def logout():
    session.pop("user", None)
    return redirect(url_for("login"))


@app.route("/", methods=["GET", "POST"])
def index():
    if "user" not in session:
        return redirect(url_for("login"))

    # Load config to get whitelist toggle
    config = {}
    if os.path.exists(CONFIG_FILE):
        try:
            with open(CONFIG_FILE, "r") as f:
                config = json.load(f)
        except json.JSONDecodeError:
            config = {}

    if request.method == "POST":
        # Update whitelist toggle if submitted
        whitelist_enabled = bool(request.form.get("whitelist_enabled"))
        config["whitelist_enabled"] = whitelist_enabled
        with open(CONFIG_FILE, "w") as f:
            json.dump(config, f)
        flash("✅ Whitelist setting updated.", "success")
        return redirect(url_for("index"))

    # Load editable file contents
    file_contents = {}
    with file_lock:
        for name, filename in FILES.items():
            if os.path.exists(filename):
                with open(filename, "r") as f:
                    file_contents[name] = f.read()
            else:
                file_contents[name] = ""

    # Load logs
    log_content = ""
    with file_lock:
        if os.path.exists(LOG_FILE):
            with open(LOG_FILE, "r") as f:
                log_content = f.read()[-5000:]

    return render_template_string(TEMPLATE,
        files=FILES,
        file_contents=file_contents,
        log_content=log_content,
        whitelist_enabled=config.get("whitelist_enabled", False)
    )


    return render_template_string(TEMPLATE, files=FILES, file_contents=file_contents, log_content=log_content)

@app.route("/edit/<file_key>", methods=["POST"])
def edit_file(file_key):
    filename = FILES.get(file_key)
    if filename:
        content = request.form.get("content", "")
        with file_lock:
            with open(filename, "w") as f:
                f.write(content)
    return redirect(url_for('index'))

@app.route("/refresh_log", methods=["POST"])
def refresh_log():
    return redirect(url_for('index'))

@app.route("/logs")
def logs():
    with file_lock:
        if os.path.exists(LOG_FILE):
            with open(LOG_FILE, "r") as f:
                return f.read()[-5000:]  # Last 5000 chars
    return "No logs available."

CONFIG_FILE = "data/user_config.json"

@app.route("/settings", methods=["GET", "POST"])
def settings():
    if "user" not in session:
        return redirect(url_for("login"))

    config = {}
    if os.path.exists(CONFIG_FILE):
        try:
            with open(CONFIG_FILE, "r") as f:
                config = json.load(f)
        except json.JSONDecodeError:
            logging.warning("Invalid JSON in config file.")
            config = {}

    if request.method == "POST":
        bot_token = request.form.get("bot_token", "").strip()
        chat_id = request.form.get("chat_id", "").strip()
        whitelist_enabled = bool(request.form.get("whitelist_enabled"))

        config = {
            "bot_token": bot_token,
            "chat_id": chat_id,
        }

        with open(CONFIG_FILE, "w") as f:
            json.dump(config, f)

        flash("✅ Settings saved.", "success")
        return redirect(url_for("settings"))

    return render_template_string("""
    <!DOCTYPE html>
    <html>
    <head>
        <title>Telegram & Proxy Settings</title>
        <style>
            body {
                font-family: Arial, sans-serif;
                max-width: 600px;
                margin: 40px auto;
                background-color: #f9f9f9;
                padding: 30px;
                border-radius: 10px;
                box-shadow: 0 0 10px rgba(0,0,0,0.1);
            }
            h2 {
                color: #333;
            }
            label {
                font-weight: bold;
                display: block;
                margin-top: 20px;
            }
            input[type="text"], input[type="checkbox"] {
                width: 100%;
                padding: 8px;
                margin-top: 4px;
                border: 1px solid #ccc;
                border-radius: 5px;
            }
            .checkbox-label {
                display: flex;
                align-items: center;
                margin-top: 20px;
            }
            .checkbox-label input {
                width: auto;
                margin-right: 10px;
            }
            button {
                background-color: #4CAF50;
                color: white;
                padding: 10px 18px;
                border: none;
                border-radius: 5px;
                cursor: pointer;
                font-size: 16px;
                margin-top: 20px;
            }
            button:hover {
                background-color: #45a049;
            }
            a {
                display: inline-block;
                margin-top: 20px;
                color: #007BFF;
                text-decoration: none;
            }
            a:hover {
                text-decoration: underline;
            }
        </style>
    </head>
    <body>
        <h2>🔧 Proxy & Telegram Settings</h2>
        <form method="post">
            <label for="bot_token">🤖 Bot Token:</label>
            <input id="bot_token" name="bot_token" type="text" value="{{ config.get('bot_token', '') }}" required>

            <label for="chat_id">📩 Chat ID:</label>
            <input id="chat_id" name="chat_id" type="text" value="{{ config.get('chat_id', '') }}" required>
            <button type="submit">💾 Save Settings</button>
        </form>

        <a href="/">⬅️ Back to Dashboard</a>
    </body>
    </html>
    """, config=config)


FILES = {
    "Blocked Sites": "data/blocked_sites.txt",
    "Filtered Words": "data/filtered_words.txt",
    "Word Replacements": "data/word_replacements.txt",
    "Whitelist": "data/whitelist.txt",
    "Blocked Extensions": "data/blocked_extensions.txt"  

}

LOGIN_TEMPLATE = """
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Login</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      background-color: #f2f2f2;
      display: flex;
      justify-content: center;
      align-items: center;
      height: 100vh;
    }
    .login-container {
      background-color: #fff;
      padding: 2em;
      border-radius: 8px;
      box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
      width: 300px;
    }
    .login-container h2 {
      margin-bottom: 1em;
      text-align: center;
    }
    .login-container input {
      width: 100%;
      padding: 10px;
      margin: 0.5em 0;
      border: 1px solid #ccc;
      border-radius: 4px;
    }
    .login-container button {
      width: 100%;
      padding: 10px;
      background-color: #4285f4;
      color: white;
      border: none;
      border-radius: 4px;
      cursor: pointer;
    }
    .login-container button:hover {
      background-color: #357ae8;
    }
    .messages {
      color: red;
      margin-bottom: 1em;
    }
    .messages ul {
      padding-left: 1.2em;
    }
  </style>
</head>
<body>
  <div class="login-container">
    <h2>Login</h2>

    {% with messages = get_flashed_messages(with_categories=true) %}
      {% if messages %}
        <div class="messages">
          <ul>
            {% for category, message in messages %}
              <li>{{ message }}</li>
            {% endfor %}
          </ul>
        </div>
      {% endif %}
    {% endwith %}

    <form method="post">
      <input name="username" placeholder="Username" required>
      <input name="password" type="password" placeholder="Password" required>
      <button type="submit">Login</button>
    </form>
  </div>
</body>
</html>
"""

REGISTER_TEMPLATE = """
<h2>Register Admin</h2>
<form method="post">
  <input name="username" placeholder="New Username" required>
  <input name="password" type="password" placeholder="New Password" required>
  <button type="submit">Register</button>
</form>
"""

TEMPLATE = """
<!doctype html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Proxy Dashboard</title>

  <!-- Bootstrap + Google Fonts -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600&display=swap" rel="stylesheet">

  <style>
    body {
      font-family: 'Inter', sans-serif;
      background-color: var(--bg);
      color: var(--text);
      transition: background-color 0.3s, color 0.3s;
    }
    :root {
      --bg: #f5f7fa;
      --text: #1a1a1a;
      --card-bg: #ffffff;
      --log-bg: #212529;
      --log-text: #f8f9fa;
    }
    body.dark-mode {
      --bg: #1a1a1a;
      --text: #eaeaea;
      --card-bg: #2b2b2b;
      --log-bg: #111;
      --log-text: #ddd;
    }

    /* Fix headings/labels in dark mode */
    h1, h2, h3, h4, h5, h6,
    label, .form-label, .card h4,
    .top-bar h2 {
      color: var(--text);
    }

    body.dark-mode .form-control::placeholder {
      color: #aaa;
    }

    .card {
      background-color: var(--card-bg);
      border: none;
      border-radius: 1rem;
      box-shadow: 0 4px 20px rgba(0, 0, 0, 0.05);
    }
    .blurred {
        opacity: 0.5;
        position: relative;
    }

    .disabled-section {
        cursor: not-allowed;
    }

    .btn-primary {
      background-color: #4e73df;
      border: none;
    }
    .btn-primary:hover {
      background-color: #2e59d9;
    }
    .top-bar {
      background-color: var(--card-bg);
      padding: 1rem 2rem;
      border-radius: 1rem;
      margin-bottom: 2rem;
      display: flex;
      justify-content: space-between;
      align-items: center;
      box-shadow: 0 2px 8px rgba(0,0,0,0.05);
    }
    #log-box {
      background-color: var(--log-bg);
      color: var(--log-text);
      font-family: monospace;
      font-size: 0.95rem;
      padding: 1rem;
      border-radius: 0.75rem;
      height: 400px;
      overflow-y: auto;
      white-space: pre-wrap;
    }
    #log-box.expanded {
      height: 80vh;
    }
    .error {
      color: #ff6b6b;
      font-weight: bold;
    }
  </style>

  <script>
    function refreshLogs() {
        fetch('/logs')
        .then(response => response.text())
        .then(data => {
            const logBox = document.getElementById('log-box');
            const highlighted = data.replace(/(ERROR|Exception)/g, '<span class="error">$1</span>');
            logBox.innerHTML = highlighted;
            logBox.scrollTop = logBox.scrollHeight;
        })
        .catch(err => console.error("Failed to load logs:", err));
    }

    function toggleDarkMode() {
        document.body.classList.toggle("dark-mode");
        const btn = document.getElementById("dark-mode-btn");
        btn.textContent = document.body.classList.contains("dark-mode") ? "Light Mode" : "Dark Mode";
    }

    function toggleLogSize() {
        const logBox = document.getElementById("log-box");
        logBox.classList.toggle("expanded");
        document.getElementById("log-toggle-btn").textContent = logBox.classList.contains("expanded") ? "Collapse Logs" : "Expand Logs";
    }

     function disableSectionsInWhitelistMode() {
        const whitelistEnabled = {{ 'true' if whitelist_enabled else 'false' }};
        if (!whitelistEnabled) return;

        const restrictedSections = ["Blocked Sites", "Filtered Words", "Word Replacements", "Blocked Extensions"];

        document.querySelectorAll(".section-form").forEach(form => {
        const sectionName = form.dataset.section;
        if (restrictedSections.includes(sectionName)) {
            form.classList.add("blurred");

            form.querySelectorAll("textarea, button").forEach(el => {
            el.classList.add("disabled-section");

            if (el.tagName === 'TEXTAREA') {
                el.readOnly = true;
            }

            el.addEventListener("click", (e) => {
                e.preventDefault();
                alert("⚠️ Whitelist mode is enabled. You cannot edit this section.");
            });
            });

            // Prevent form submission too
            form.addEventListener("submit", (e) => {
            e.preventDefault();
            alert("⚠️ Whitelist mode is enabled. You cannot edit this section.");
            });
        }
        });
    }
    window.onload = () => {
        refreshLogs();
        setInterval(refreshLogs, 5000);
        disableSectionsInWhitelistMode();
    };
  </script>

</head>

<body>

<div class="container py-4">

  <!-- Top Bar -->
  <div class="top-bar">
    <h2 class="mb-0">Proxy Control Dashboard</h2>
    <div>
      <a href="{{ url_for('logout') }}" class="btn btn-sm btn-danger me-2">Logout</a>
      <button class="btn btn-sm btn-outline-secondary" onclick="toggleDarkMode()" id="dark-mode-btn">Dark Mode</button>
    </div>
  </div>

  <!-- Whitelist Toggle -->
  <div class="card p-4 mb-4">
    <form method="post">
        <h4 class="mb-3">🔒 Whitelist Mode Only</h4>
        <div class="form-check form-switch">
        <input class="form-check-input" type="checkbox" id="whitelist_enabled" name="whitelist_enabled" {% if whitelist_enabled %}checked{% endif %}>
        <label class="form-check-label" for="whitelist_enabled">Enable regex-based domain whitelist</label>
        </div>
        <button type="submit" class="btn btn-success mt-3">💾 Save Whitelist Setting</button>
    </form>
  </div>

  <!-- Configuration Editor -->
  <div class="card p-4 mb-4">
    <h4 class="mb-4">Edit Configuration Files</h4>
    {% for name, filename in files.items() %}
    <form method="post" action="{{ url_for('edit_file', file_key=name) }}" class="mb-4 section-form" data-section="{{ name }}">
    <label class="form-label fw-semibold">{{ name }}</label>
    <textarea class="form-control mb-2 section-input" name="content" rows="6">{{ file_contents.get(name, '') }}</textarea>
    <button type="submit" class="btn btn-primary section-button">Save {{ name }}</button>
    </form>
    {% endfor %}
  </div>

  <!-- Log Viewer -->
  <div class="card p-4">
    <div class="d-flex justify-content-between align-items-center mb-3">
      <h4 class="mb-0">Proxy Logs</h4>
      <button class="btn btn-sm btn-secondary" id="log-toggle-btn" onclick="toggleLogSize()">Expand Logs</button>
    </div>
    <div id="log-box">{{ log_content }}</div>
  </div>

</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>
"""


def main():

    ensure_data_files()
    # Start proxy server in a separate thread
    threading.Thread(target=start_proxy, daemon=True).start()
    # Start dashboard server
    serve(app, host="0.0.0.0", port=5000)

# ==========================
# Start Proxy and Web Dashboard
# ==========================

if __name__ == "__main__":

    main()


